c----- paramt.h to be included --------
      parameter( ix=1026, is=3, in=12288 + 8 )
